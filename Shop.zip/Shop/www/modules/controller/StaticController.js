/**
 * Created by ASUS on 2017/7/18 0018.
 */
require('../../../node_shit/base/app/ShitController').inheritsShitController(StaticController);

var config = require('../../../node_shit/common/config').app;

var fs = require('fs');

function StaticController() {

    this.js = function (params, body, res) {
        var path = config.staticPath + '/js/' + params.path;
        var data = fs.readFileSync(path, config.templatesCharset);
        res.end(data);
    }

    this.css = function (params, body, res) {
        var path = config.staticPath + '/css/' + params.path;
        var data = fs.readFileSync(path, config.templatesCharset);
        res.end(data);
    }

}

module.exports = StaticController;