/**
 * Created by ASUS on 2017/7/17 0017.
 */
var ShitApp = require('../node_shit/base/app/ShitApp');

var app = new ShitApp();
app.start();