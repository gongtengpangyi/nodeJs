var mysql = require('./sss/db');

mysql.doQuery();